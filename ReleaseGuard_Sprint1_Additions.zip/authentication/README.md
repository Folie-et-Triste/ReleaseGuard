# Sprint 1: Add-only authentication prototype

This folder is **new**. The existing `ReleaseGuard/main.cpp`, `user.h`, and `wrapper.h` are untouched. This is an **independent demo**, not yet integrated into the team's main application.

## Build / test (requires C++17 compiler and OpenSSL development headers/libcrypto)

From this folder:

```sh
g++ -std=c++17 -Wall -Wextra -pedantic AuthService.cpp auth_tests.cpp -lcrypto -o auth_tests
./auth_tests
g++ -std=c++17 -Wall -Wextra -pedantic AuthService.cpp auth_demo.cpp -lcrypto -o auth_demo
./auth_demo
```

`auth_demo` creates `demo_accounts.txt` in the working directory (ignored by Git once the new .gitignore file is added). For repeat testing, delete this demo file, not any teammate data. Use only fictional passwords. The terminal prompts echo typed passwords and are not production ready.

## Features

- Registration: valid username, minimum eight-character password, duplicate rejection, save to a separate account file.
- Login: valid/invalid password and unknown-user handling, persisted user records reload on restart.
- Passwords stored as randomized-salt PBKDF2-HMAC-SHA256 hashes rather than plaintext.

## Important integration caveat

These functions are not wired into the existing team's `wrapper.h`; do not overwrite existing files to integrate. Coordinate with the team before integration. This minimal classroom prototype is not production authentication: it does not cover secure terminal entry, strong account management, rate limiting, locking, atomic saves, or audited session management.
